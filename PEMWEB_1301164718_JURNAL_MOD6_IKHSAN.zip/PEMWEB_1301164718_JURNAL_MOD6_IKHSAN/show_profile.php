<?php
require_once("auth.php"); 
// show profile berdasarkan ID
?>