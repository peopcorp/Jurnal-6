    <?php
        require_once("auth.php");
        include_once("config.php");
        $name = $_SESSION['user']['name'];
        $postingan = $_POST['data'];
        $sql = "INSERT INTO postingan (name, posting) VALUES ('$name', '$postingan');

        if (mysqli_query($mysqli. $sql)) {
        	echo "berhasil di record";
        	header("location : timeline.php");
        } else {
        	echo "Error :" . $sql . "<br>"" . mysqli_error($mysqli);
        }
    
    
        // Get inputan user untuk postingan


        // include database connection file


        // Insert posting data into table


    
    ?>