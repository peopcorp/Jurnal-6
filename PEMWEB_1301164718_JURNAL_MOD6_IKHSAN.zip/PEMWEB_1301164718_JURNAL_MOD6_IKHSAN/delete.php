<?php
// include database connection file
include_once("config.php");

// Get id dari URL untuk delete dari user


// Delete user row dari table sesuai id


// setelah delete redirect to Timeline, 

?>