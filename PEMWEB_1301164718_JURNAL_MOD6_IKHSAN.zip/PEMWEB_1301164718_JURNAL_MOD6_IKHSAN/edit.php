    <?php
    require_once("auth.php");
    
    
        // Get data dari HTML dengan Name di inpute
    
        // Get id dari data yang sesuai
        
        // include database connection file
        include_once("config.php");

        // update tabel posting data dari tabel sesuai inputan dengan query table
       
        
    
    ?>